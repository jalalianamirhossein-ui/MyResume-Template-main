===============================================
SCSS/SASS FILES - README
===============================================

This directory is reserved for SCSS/Sass source files.

Note: The current version uses compiled CSS files directly.
SCSS source files are available in the pro version for
easier customization and maintenance.

For SCSS source files and advanced customization,
visit: https://meetaj.ir

===============================================