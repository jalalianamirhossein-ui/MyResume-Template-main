import React, { useEffect, useState } from 'react';

const Preloader = ({ isVisible = true, language = 'en' }) => {
  const [isLoading, setIsLoading] = useState(isVisible);

  useEffect(() => {
    setIsLoading(isVisible);
  }, [isVisible]);

  if (!isLoading) return null;

  const isRTL = language === 'fa' || language === 'ar';
  const loadingText = isRTL ? 'در حال بارگذاری...' : 'Loading...';

  return (
    <div className={`preloader-overlay ${isLoading ? 'visible' : 'hidden'}`}>
      <div className={`preloader-container ${isRTL ? 'rtl' : 'ltr'}`}>
        {/* Spinning Circle Animation */}
        <div className="preloader-spinner">
          <div className="spinner-circle">
            <div className="spinner-inner"></div>
          </div>
        </div>
        
        {/* Loading Text */}
        <div className="preloader-text">
          <span className="loading-text">{loadingText}</span>
        </div>
        
        {/* Progress Line Animation */}
        <div className="preloader-progress">
          <div className="progress-line"></div>
        </div>
      </div>
      
      <style jsx>{`
        .preloader-overlay {
          position: fixed;
          top: 0;
          left: 0;
          width: 100%;
          height: 100%;
          background: #f9f9f9;
          z-index: 9999;
          display: flex;
          align-items: center;
          justify-content: center;
          opacity: 0;
          visibility: hidden;
          transition: all 0.3s ease-in-out;
        }
        
        .preloader-overlay.visible {
          opacity: 1;
          visibility: visible;
        }
        
        .preloader-overlay.hidden {
          opacity: 0;
          visibility: hidden;
        }
        
        .preloader-container {
          display: flex;
          flex-direction: column;
          align-items: center;
          gap: 24px;
          max-width: 300px;
          width: 100%;
          padding: 20px;
        }
        
        .preloader-container.rtl {
          direction: rtl;
        }
        
        .preloader-container.ltr {
          direction: ltr;
        }
        
        /* Spinner Animation */
        .preloader-spinner {
          position: relative;
          width: 60px;
          height: 60px;
        }
        
        .spinner-circle {
          width: 100%;
          height: 100%;
          border: 3px solid rgba(37, 99, 235, 0.1);
          border-top: 3px solid #2563eb;
          border-radius: 50%;
          animation: spin 1s linear infinite;
        }
        
        .spinner-inner {
          position: absolute;
          top: 50%;
          left: 50%;
          transform: translate(-50%, -50%);
          width: 30px;
          height: 30px;
          border: 2px solid rgba(37, 99, 235, 0.2);
          border-top: 2px solid #2563eb;
          border-radius: 50%;
          animation: spin 0.8s linear infinite reverse;
        }
        
        @keyframes spin {
          0% { transform: rotate(0deg); }
          100% { transform: rotate(360deg); }
        }
        
        /* Loading Text */
        .preloader-text {
          text-align: center;
        }
        
        .loading-text {
          font-family: 'Vazirmatn', 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
          font-size: 18px;
          font-weight: 500;
          color: #333;
          letter-spacing: 0.5px;
          animation: pulse 2s ease-in-out infinite;
        }
        
        .rtl .loading-text {
          font-family: 'Vazirmatn', 'Tahoma', sans-serif;
        }
        
        @keyframes pulse {
          0%, 100% { opacity: 0.7; }
          50% { opacity: 1; }
        }
        
        /* Progress Line Animation */
        .preloader-progress {
          width: 200px;
          height: 3px;
          background: rgba(37, 99, 235, 0.1);
          border-radius: 2px;
          overflow: hidden;
          position: relative;
        }
        
        .progress-line {
          height: 100%;
          background: linear-gradient(90deg, #2563eb, #3b82f6);
          border-radius: 2px;
          animation: progress 2s ease-in-out infinite;
          transform-origin: left;
        }
        
        @keyframes progress {
          0% { 
            transform: scaleX(0);
            transform-origin: left;
          }
          50% { 
            transform: scaleX(0.7);
            transform-origin: left;
          }
          100% { 
            transform: scaleX(1);
            transform-origin: left;
          }
        }
        
        /* RTL Progress Line */
        .rtl .progress-line {
          transform-origin: right;
        }
        
        .rtl .progress-line {
          animation: progressRTL 2s ease-in-out infinite;
        }
        
        @keyframes progressRTL {
          0% { 
            transform: scaleX(0);
            transform-origin: right;
          }
          50% { 
            transform: scaleX(0.7);
            transform-origin: right;
          }
          100% { 
            transform: scaleX(1);
            transform-origin: right;
          }
        }
        
        /* Responsive Design */
        @media (max-width: 768px) {
          .preloader-container {
            gap: 20px;
            padding: 16px;
          }
          
          .preloader-spinner {
            width: 50px;
            height: 50px;
          }
          
          .spinner-inner {
            width: 25px;
            height: 25px;
          }
          
          .loading-text {
            font-size: 16px;
          }
          
          .preloader-progress {
            width: 160px;
            height: 2px;
          }
        }
        
        @media (max-width: 480px) {
          .preloader-container {
            gap: 16px;
            padding: 12px;
          }
          
          .preloader-spinner {
            width: 40px;
            height: 40px;
          }
          
          .spinner-inner {
            width: 20px;
            height: 20px;
          }
          
          .loading-text {
            font-size: 14px;
          }
          
          .preloader-progress {
            width: 120px;
            height: 2px;
          }
        }
        
        /* High DPI Displays */
        @media (-webkit-min-device-pixel-ratio: 2), (min-resolution: 192dpi) {
          .spinner-circle,
          .spinner-inner {
            border-width: 2px;
          }
        }
        
        /* Reduced Motion Support */
        @media (prefers-reduced-motion: reduce) {
          .spinner-circle,
          .spinner-inner {
            animation: none;
          }
          
          .loading-text {
            animation: none;
            opacity: 1;
          }
          
          .progress-line {
            animation: none;
            transform: scaleX(1);
          }
        }
        
        /* Dark Mode Support */
        @media (prefers-color-scheme: dark) {
          .preloader-overlay {
            background: #1a1a1a;
          }
          
          .loading-text {
            color: #ffffff;
          }
          
          .spinner-circle {
            border-color: rgba(37, 99, 235, 0.2);
            border-top-color: #2563eb;
          }
          
          .spinner-inner {
            border-color: rgba(37, 99, 235, 0.3);
            border-top-color: #2563eb;
          }
          
          .preloader-progress {
            background: rgba(37, 99, 235, 0.2);
          }
        }
      `}</style>
    </div>
  );
};

export default Preloader;
